                                        
                                                                                          
                    PRE/POST                        hNNNNNN/                              
                      2012                         sMMMMMMs                               
                                                  oMMMMMMh`                               
                                                 /MMMMMMd`                                
                                                :NMMMMMm.                                 
                                               .NMMMMMN-                                  
                                              `mMMMMMN/                                   
                                             `hMMMMMM+                                    
                                             yMMMMMMs                                     
                                            oMMMMMMy                                      
                                           +MMMMMMd`                                      
                                          :NMMMMMm.                                       
                                         -NMMMMMN-                                        
                                        .mMMMMMN:                                         
                                       `dMMMMMM/                                          
                                       hMMMMMMo                                           
                                      sMMMMMMy                                            
                                     +MMMMMMh                                             
                                    /MMMMMMm`                                             
                                   -NMMMMMN.                                              
                                  .NMMMMMN-                                               
                                 `mMMMMMM:                                                
                                 hMMMMMM+                                                 
                                yMMMMMMs                                                  
                               oMMMMMMh                                                   
                              /MMMMMMd`                                                   
                             :NMMMMMm.                                                    
                            -NMMMMMN-                                                     
                           .mMMMMMN:                                                      
                          `dMMMMMM+                                                       
                          yMMMMMMo                                                        
                         sMMMMMMy                                                         
                        +MMMMMMh`                                                         
                       /MMMMMMm`                                                          
                      -NMMMMMm.                                                           
                     .mMMMMMN:                                                            
                    `dMMMMMM/                                                             
                   `hMMMMMMo
                   sMMMMMMs
                  +NNNNNNh                                                                
                  -------`                                                                                            
                                                           

  -------------------------------------------------------------------------------
  HELLO!
  ===============================================================================
  Thanks for purchasing a PRE/POST digital edition! 

  If you're reading this, you purchased the digital book bundle. This bundle 
  contains a few different file formats:

   * EPUB
   * MOBI
   * PDF

  EPUB is the industry standard ebook format and works well on iPads and iPhones
       (and Nooks and Sony Readers and Kobos and …).
  MOBI is for Kindle devices. 
  PDF is good for reading on your desktop/laptop computer (Windows or Mac).

  

  -------------------------------------------------------------------------------
  READING
  ===============================================================================
  So how do you use these files? Good question. We'll help you get started on the 
  most common platforms but you'll have to contact your device maker if you have 
  a non-standard ebook reading device. 


  iPhone / iPad / iPod Touch
  ---------------------------
  1. Make you sure you have installed the iBooks app on your iPhone / iPad. It's 
     available for free in the iTunes App Store. 
  2. Drag the .EPUB file into iTunes (yes, iTunes), then sync your device. The book
     should appear in iBooks on your device following the completed sync. 


  Nook
  ---------------------------
  1. Add the .EPUB file to the "my documents" folder of your Nook. 


  Kindle
  ---------------------------
  1. Connect your Kindle to your computer with the little USB cord. Open your Kindle 
     in a file browser (like Finder, on Mac), drag the .MOBI file into the 'documents'
     folder on the Kindle. 
  2. OR! Download the desktop application "Send to Kindle (for Mac / for PC)". Once
     downloaded and installed, drag the .MOBI onto the Send to Kindle application. 


  -------------------------------------------------------------------------------
  SUPPORT
  ===============================================================================
  Not working? We'll try to help: support@prepostbooks.com

  Thanks again, and we hope you enjoy the books. 



